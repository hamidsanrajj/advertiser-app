import './Team.css';
import blankProfilePic from './img/blank-profile-picture.webp';

const Team = () => (
  <div className="Team">
    <h1 className='Heading-Main'>Team</h1>


    <div id='team' className="bg-light py-3 py-md-5 py-xl-8">
      <div className="container">
        <div className="row justify-content-md-center">
          <div className="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
            <p className="text-secondary mb-5 text-center lead fs-4">We are a group of innovative, experienced, and proficient teams. You will love to collaborate with us.</p>
            <hr className="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle" />
          </div>
        </div>
      </div>

      <div className="container overflow-hidden">
        <div className="row gy-4 gy-lg-0 gx-xxl-5">
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Flora Nyra" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Naeem Gohar</h4>
                    <p className="text-secondary mb-0">Product Manager</p>
                    <p className="text-secondary mb-0">03356699972</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Evander Mac" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Hamid Mehmood</h4>
                    <p className="text-secondary mb-0">Art Director</p>
                    <p className="text-secondary mb-0">03360591298</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Taytum Elia" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Zafar Iqbal</h4>
                    <p className="text-secondary mb-0">Investment Planner</p>
                    <p className="text-secondary mb-0">03352228913</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Wylder Elio" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Wylder Elio</h4>
                    <p className="text-secondary mb-0">Financial Analyst</p>
                    <p className="text-secondary mb-0">03235508596</p>
                    <p className="text-secondary mb-0"></p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


  </div>
);

Team.propTypes = {};

Team.defaultProps = {};

export default Team;
