import './Clients.css';
import clientsImage1 from './img/clients/Air_University_Pakistan_Insignia.png';
import clientsImage2 from './img/clients/bahria-university-logo.png';
import clientsImage3 from './img/clients/National_University_of_Computer_and_Emerging_Sciences_logo.png';
// import clientsImage4 from './img/clients/UOSwabi-Logo.jpeg';
import clientsImage5 from './img/clients/dc-haripur.jpeg';
import clientsImage6 from './img/clients/dc-faisalabad.jpg';
import clientsImage7 from './img/clients/dc-skardu.png';

const Clients = () => (
  <div className="Clients">
    <h1 className='Heading-Main'>Clients</h1>
    
    <div className="clients py-lg-8 py-6">
      {/* <h1 className="clientsHeading">Clients</h1> */}
		 <div class="container py-lg-6">
				<div class="row">
					 <div class="col-md-12">
							<div class="d-flex justify-content-center text-center mb-6">
								 <h5 className="clientsHeadingh5">Loved by over 5 million users from companies like</h5>
							</div>
					 </div>
				</div>
				<div class="row row-cols-xl-7 gy-6">
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage1} alt="logo 1" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage2} alt="logo 2" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage3} alt="logo 3" />
					 </div>
					 {/* <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage4} alt="logo 4" />
					 </div> */}
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage5} alt="logo 5" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage6} alt="logo 6" />
					 </div>
					 <div class="text-center col">
							<img src={clientsImage7} alt="logo 7" />
					 </div>
				</div>
		 </div>
    </div>
  </div>
);

Clients.propTypes = {};

Clients.defaultProps = {};

export default Clients;
