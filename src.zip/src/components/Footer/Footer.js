import './Footer.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { NavLink } from "react-router-dom";
import Logo from "./Logo2.png";

const Footer = () => (
  <div className="Footer bg-light">
      <Row>
        <Col md={4}>
          <img className="Logo" src={Logo} alt="" />
        </Col>
        <Col md={4}>
          <h3>Info Links</h3>
       <div
         className={"nav__menu"}
         id="nav-menu">
         <ul className="nav__list">
           <li className="nav__item">
             <NavLink to="/" className="nav__link item_nav"> 
               Home
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/about" className="nav__link">
               About
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/clients" className="nav__link">
               Clients
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/contact" className="nav__link">
               Contact
             </NavLink>
           </li>
         </ul>
       </div>
        </Col>
        <Col md={4}>
          <h3>Info Links</h3>
          <div
         className={"nav__menu"}
         id="nav-menu">
         <ul className="nav__list">
           <li className="nav__item">
             <NavLink to="/gallery" className="nav__link item_nav"> 
               Gallery
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/faq" className="nav__link">
               FAQ
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/team" className="nav__link">
               Team
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/testimonials" className="nav__link">
               Testimonials
             </NavLink>
           </li>
         </ul>
       </div>
        </Col>
      </Row>
      <Row className='rwCopyrights'>
        <Col md={4}></Col>
        <Col md={4} className='copyright'>© 2025, Coprights All Rights Reserved.</Col>
        <Col md={4}></Col>
      </Row>
  </div>
);

Footer.propTypes = {};

Footer.defaultProps = {};

export default Footer;
