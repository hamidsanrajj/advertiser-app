import React, { useState } from 'react';
import './Contact.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Contact = () => {

  const [name, setName] = useState({})
  const [email, setEmail] = useState({})
  const [phone, setPhone] = useState({})
  const [message, setMessage] = useState({})

  const nameVal = (event) => {
  const name = event.target.name;
  const value = event.target.value;
  setName(values => ({...values, [name]: value}))
 }

 const emailVal = (event) => {
  const email = event.target.name;
  const value = event.target.value;
  setEmail(values => ({...values, [email]: value}))
 }

 const PhoneVal = (event) => {
  const email = event.target.name;
  const value = event.target.value;
  setPhone(values => ({...values, [email]: value}))
 }
 
 const messageVal = (event) => {
  const email = event.target.name;
  const value = event.target.value;
  setMessage(values => ({...values, [email]: value}))
 } 

 const dataSubmit = (event) => {
  event.preventDefault();
  let a = JSON.stringify(name);
  let b = JSON.stringify(email);
  let c = JSON.stringify(phone);
  let d = JSON.stringify(message);

  const y = JSON.parse(a);
  const y2 = JSON.parse(b);
  const y3 = JSON.parse(c);
  const y4 = JSON.parse(d);

  var x = y.name;
  var x2 = y2.email;
  var x3 = y3.phone;
  var x4 = y4.message;
  // document.getElementById("name").innerHTML = x;
  // document.getElementById("email").innerHTML = x2;
  // document.getElementById("phone").innerHTML = x3;
  // document.getElementById("message").innerHTML = x4;
  window.location.href = 'http://localhost/api/server.php?name='+x+'&email='+x2+'&phone='+x3+'&message='+x4;
 }

 return <form className='contact' onSubmit={dataSubmit}>
 <div>
<h1 className='Heading-Main'>Contact</h1>
    <Row>
        <Col md={3}></Col>
        <Col md={6}>
        <h1 className='contactHeading'>Contact Us</h1>
          <div data-mdb-input-init className="form-outline mb-4 mt-4">
            <label className="form-label" for="form4Example1">Name</label>
            <input type="text" name='name' id="form4Example1" className="form-control" onChange={nameVal} />
          </div>

          <div data-mdb-input-init className="form-outline mb-4">
            <label className="form-label" for="form4Example2">Email address</label>
            <input type="email" name='email' id="form4Example2" className="form-control" onChange={emailVal} />
          </div>

          <div data-mdb-input-init className="form-outline mb-4">
            <label className="form-label" for="form4Example2">Phone Number</label>
            <input type="number" name='phone' id="form4Example2" className="form-control" onChange={PhoneVal} />
          </div>

          <div data-mdb-input-init className="form-outline mb-4">
            <label className="form-label" for="form4Example3">Message</label>
            <textarea className="form-control" name='message' id="form4Example3" rows="4" onChange={messageVal}></textarea>
          </div>

          <button data-mdb-ripple-init type="submit" name='submit' className="btn btn-primary btn-block mb-4">Send</button>

          {/* <div id='name'>
  
          </div>
          <div id='email'>
            
          </div>
          <div id='phone'>
            
          </div>
          <div id='message'>
            
          </div> */}

        </Col>
        <Col md={3}></Col>
    </Row>
 </div>
 </form>


};

Contact.propTypes = {};

Contact.defaultProps = {};

export default Contact;