import './Testimonials.css';
import blankProfilePic from './img/blank-profile-picture.webp';

const Testimonials = () => (
  <div className="Testimonials">
    <h1 className='Heading-Main'>Testimonials</h1>

    <div id="testimonials" className="testimonial-carousel">
    {/* <h1 className='testimonialsHeading'>Testimonials</h1> */}
    <div className="container">
        <div id="testimonialCarousel" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-inner">
                <div className="carousel-item active">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 1" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"This product has completely transformed the way I work. It's intuitive,
                            powerful, and a game-changer for my productivity!"</p>
                        <h5 className="fw-bold mb-1">Sarah Johnson</h5>
                        <p className="text-muted">Marketing Director</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 2" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"I've tried many similar products, but this one stands out. The attention
                            to detail and customer support are unmatched."</p>
                        <h5 className="fw-bold mb-1">Michael Chen</h5>
                        <p className="text-muted">Software Engineer</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 3" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"This solution has streamlined our processes and improved team
                            collaboration. It's been a fantastic investment for our company."</p>
                        <h5 className="fw-bold mb-1">Emily Rodriguez</h5>
                        <p className="text-muted">Project Manager</p>
                    </div>
                </div>
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    </div>

  </div>
);

Testimonials.propTypes = {};

Testimonials.defaultProps = {};

export default Testimonials;
