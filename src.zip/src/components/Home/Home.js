import './Home.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Accordion from 'react-bootstrap/Accordion';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Carousel from '../Carousel/Carousel';
import aboutImg from './img/large-format-printing.jpg';
import galleryImage1 from './img/gallery/brouchers.jpg'
import galleryImage2 from './img/gallery/mugs.webp';
import galleryImage3 from './img/gallery/shields.jpeg';
import galleryImage4 from './img/gallery/stamp.webp';
import galleryImage5 from './img/gallery/envelopes.webp';
import galleryImage6 from './img/gallery/t-shirts.jpg';
import blankProfilePic from './img/blank-profile-picture.webp';
import clientsImage1 from './img/clients/Air_University_Pakistan_Insignia.png';
import clientsImage2 from './img/clients/bahria-university-logo.png';
import clientsImage3 from './img/clients/National_University_of_Computer_and_Emerging_Sciences_logo.png';
// import clientsImage4 from './img/clients/UOSwabi-Logo.jpeg';
import clientsImage5 from './img/clients/dc-haripur.jpeg';
import clientsImage6 from './img/clients/dc-faisalabad.jpg';
import clientsImage7 from './img/clients/dc-skardu.png';
import { Link } from 'react-router-dom';
import imageFoodTruck from './img/food-truck.jpg';
import printingImage from './img/digital-priniting_367726020_S.jpg';
import advertisingPoster from './img/Advertising-Poster-Templates.png';

const Home = () => (
  <div className="Home">
    <Carousel />
    <div className='about py-3 py-md-5'>
      <div className="container">
        <div className="row gy-3 gy-md-4 gy-lg-0 align-items-lg-center">
          <div className="col-12 col-lg-6 col-xl-5">
            <img className="img-fluid rounded" loading="lazy" src={aboutImg} alt="About 1" />
          </div>
          <div className="col-12 col-lg-6 col-xl-7">
            <div className="row justify-content-xl-center">
              <div className="col-12 col-xl-11">
                <h2 className="mb-3">Who Are We?</h2>
                <p className="lead fs-4 text-secondary mb-3">We help people to build incredible brands and superior products. Our perspective is to furnish outstanding captivating services.</p>
                <p className="mb-5">We are a fast-growing company, but we have never lost sight of our core values. We believe in collaboration, innovation, and customer satisfaction. We are always looking for new ways to improve our products and services.</p>
                <div className="row gy-4 gy-md-0 gx-xxl-5X">
                  <div className="col-12 col-md-6">
                    <div className="d-flex">
                      <div className="me-4 text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-gear-fill" viewBox="0 0 16 16">
                          <path d="M9.405 1.05c-.413-1.4-2.397-1.4-2.81 0l-.1.34a1.464 1.464 0 0 1-2.105.872l-.31-.17c-1.283-.698-2.686.705-1.987 1.987l.169.311c.446.82.023 1.841-.872 2.105l-.34.1c-1.4.413-1.4 2.397 0 2.81l.34.1a1.464 1.464 0 0 1 .872 2.105l-.17.31c-.698 1.283.705 2.686 1.987 1.987l.311-.169a1.464 1.464 0 0 1 2.105.872l.1.34c.413 1.4 2.397 1.4 2.81 0l.1-.34a1.464 1.464 0 0 1 2.105-.872l.31.17c1.283.698 2.686-.705 1.987-1.987l-.169-.311a1.464 1.464 0 0 1 .872-2.105l.34-.1c1.4-.413 1.4-2.397 0-2.81l-.34-.1a1.464 1.464 0 0 1-.872-2.105l.17-.31c.698-1.283-.705-2.686-1.987-1.987l-.311.169a1.464 1.464 0 0 1-2.105-.872l-.1-.34zM8 10.93a2.929 2.929 0 1 1 0-5.86 2.929 2.929 0 0 1 0 5.858z" />
                        </svg>
                      </div>
                      <div>
                        <h2 className="h4 mb-3">Versatile Brand</h2>
                        <p className="text-secondary mb-0">We are crafting a digital method that subsists life across all mediums.</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-6">
                    <div className="d-flex">
                      <div className="me-4 text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-fire" viewBox="0 0 16 16">
                          <path d="M8 16c3.314 0 6-2 6-5.5 0-1.5-.5-4-2.5-6 .25 1.5-1.25 2-1.25 2C11 4 9 .5 6 0c.357 2 .5 4-2 6-1.25 1-2 2.729-2 4.5C2 14 4.686 16 8 16Zm0-1c-1.657 0-3-1-3-2.75 0-.75.25-2 1.25-3C6.125 10 7 10.5 7 10.5c-.375-1.25.5-3.25 2-3.5-.179 1-.25 2 1 3 .625.5 1 1.364 1 2.25C11 14 9.657 15 8 15Z" />
                        </svg>
                      </div>
                      <div>
                        <h2 className="h4 mb-3">Digital Agency</h2>
                        <p className="text-secondary mb-0">We believe in innovation by merging primary with elaborate ideas.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className='services services-section' id="services">
      <h1 className='headingServices'>Services</h1>
      {/* <Container>
        <Row className='service-1'>
          <Col md={4} className='service'>Service 1</Col>
          <Col md={4} className='service'>Service 2</Col>
          <Col md={4} className='service'>Service 3</Col>
        </Row>
        <Row className='service-2'> 
          <Col md={4} className='service'>Service 1</Col>
          <Col md={4} className='service'>Service 2</Col>
          <Col md={4} className='service'>Service 3</Col>
        </Row>
      </Container> */}

    <div className="container">
        <div className="row">
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Large Format Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Signage</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Instore Branding</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Vehicle Branding</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Creative Ideas</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Laser Cutting</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>OffSet Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>UV FlatBed Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Fiber Metal Marking</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>

    <div className='gallery'>
      <h1 className='galleryHeading'>Gallery</h1>
      <div class="row">
        <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
          <img
            src={galleryImage1}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Boat on Calm Water"
          />

          <img
            src={galleryImage2}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Wintry Mountain Landscape"
          />
        </div>

        <div class="col-lg-4 mb-4 mb-lg-0">
          <img
            src={galleryImage3}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Mountains in the Clouds"
          />

          <img
            src={galleryImage6}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Boat on Calm Water"
          />
        </div>

        <div class="col-lg-4 mb-4 mb-lg-0">
          <img
            src={galleryImage5}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Waves at Sea"
          />

          <img
            src={galleryImage4}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Yosemite National Park"
          />
        </div>
      </div>
    </div>

    <div className='faq'> 
      <h1 className='faqHeading'>FAQ's</h1>
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0">
          <Accordion.Header>What is Large Format Printing ?</Accordion.Header>
          <Accordion.Body>
            Large format printing is a specialized printing process used to produce graphics and prints larger than what standard desktop or commercial printers can handle. It typically involves using specialized equipment like flatbed printers or roll-to-roll printers to print on materials like banners, posters, and trade show displays. These prints are often used for advertising, signage, and visual communication in larger spaces. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="1">
          <Accordion.Header>What is Signage ?</Accordion.Header>
          <Accordion.Body>
            Signage is the design or use of signs and symbols to communicate a message. Signage also means signs collectively or being considered as a group. The term signage is documented to have been popularized in 1975 to 1980. Signs are any kind of visual graphics created to display information to a particular audience.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="2">
          <Accordion.Header>What is Instore Branding ?</Accordion.Header>
          <Accordion.Body>
            In-store branding is a strategic approach that uses visual elements, product placement, and even sensory experiences within a store to create a consistent and memorable brand experience for customers. It's about expressing a brand's identity, values, and products through the physical environment, aiming to make customers feel connected to the brand and its message. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="3">
          <Accordion.Header>What is Vehicle Branding ?</Accordion.Header>
          <Accordion.Body>
            The goal of vehicle branding is to turn your company vehicle into a mobile billboard that showcases your brand wherever it goes. Whether you have a single company car, van, lorry, or an entire fleet of vehicles, vehicle branding can significantly boost your marketing efforts.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="4">
          <Accordion.Header>What is Laser Cutting ?</Accordion.Header>
          <Accordion.Body>
            Laser cutting is a technology that uses a laser to vaporize materials, resulting in a cut edge. While typically used for industrial manufacturing applications, it is now used by schools, small businesses, architecture, and hobbyists. Laser cutting works by directing the output of a high-power laser most commonly through optics. The laser optics and CNC (computer numerical control) are used to direct the laser beam to the material. A commercial laser for cutting materials uses a motion control system to follow a CNC or G-code of the pattern to be cut onto the material. The focused laser beam is directed at the material, which then either melts, burns, vaporizes away, or is blown away by a jet of gas, leaving an edge with a high-quality surface finish.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="5">
          <Accordion.Header>What is Offset Printing ?</Accordion.Header>
          <Accordion.Body>
            Offset printing, also known as offset lithography, is a printing process where ink is transferred from a plate to a rubber blanket, which then transfers the image to the printing surface. This "offset" step reduces wear and tear on the plate and allows for high-quality printing on various substrates. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="6">
          <Accordion.Header>What is UV Flat Bed Printing ?</Accordion.Header>
          <Accordion.Body>
            UV flatbed printing is a digital printing process that uses ultraviolet light to instantly cure and dry ink on a flatbed surface. It allows for printing on a wide variety of materials, including rigid and flexible substrates, and is known for its high-quality, durable prints and fast turnaround times. 
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>
    </div>

    <div id='team' className="bg-light py-3 py-md-5 py-xl-8">
      <div className="container">
        <div className="row justify-content-md-center">
          <div className="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
            <h2 className="mb-4 display-5 text-center">Our Team</h2>
            <p className="text-secondary mb-5 text-center lead fs-4">We are a group of innovative, experienced, and proficient teams. You will love to collaborate with us.</p>
            <hr className="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle" />
          </div>
        </div>
      </div>

      <div className="container overflow-hidden">
        <div className="row gy-4 gy-lg-0 gx-xxl-5">
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Flora Nyra" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Naeem Gohar</h4>
                    <p className="text-secondary mb-0">Product Manager</p>
                    <p className="text-secondary mb-0">03356699972</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Evander Mac" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Hamid Mehmood</h4>
                    <p className="text-secondary mb-0">Art Director</p>
                    <p className="text-secondary mb-0">03360591298</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Taytum Elia" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Zafar Iqbal</h4>
                    <p className="text-secondary mb-0">Investment Planner</p>
                    <p className="text-secondary mb-0">03352228913</p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6 col-lg-3">
            <div className="card border-0 border-bottom border-primary shadow-sm overflow-hidden">
              <div className="card-body p-0">
                <figure className="m-0 p-0">
                  <img className="img-fluid" loading="lazy" src={blankProfilePic} alt="Wylder Elio" />
                  <figcaption className="m-0 p-4">
                    <h4 className="mb-1">Wylder Elio</h4>
                    <p className="text-secondary mb-0">Financial Analyst</p>
                    <p className="text-secondary mb-0">03235508596</p>
                    <p className="text-secondary mb-0"></p>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className='blogs'>
      <h1 className='blogHeading'> Blogs </h1>
      <Row>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={imageFoodTruck} className='cardImage' />
              <Card.Body>
                <Card.Title>How to Design an Impactful Flyer</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025 
                </Card.Text>
                <Link to="/blog1"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={printingImage} className='cardImage' />
              <Card.Body>
                <Card.Title>How to Stand Out in a Crowded Print Market with Value-Driven Services</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025 
                </Card.Text>
                <Link to="/blog2"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={advertisingPoster} className='cardImage' />
              <Card.Body>
                <Card.Title>How to make a successful advertising poster</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025
                </Card.Text>
                <Link to="/blog3"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
      </Row>
    </div>

    <div id="testimonials" className="testimonial-carousel">
    <h1 className='testimonialsHeading'>Testimonials</h1>
    <div className="container">
        <div id="testimonialCarousel" className="carousel slide" data-bs-ride="carousel">
            <div className="carousel-inner">
                <div className="carousel-item active">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 1" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"This product has completely transformed the way I work. It's intuitive,
                            powerful, and a game-changer for my productivity!"</p>
                        <h5 className="fw-bold mb-1">Sarah Johnson</h5>
                        <p className="text-muted">Marketing Director</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 2" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"I've tried many similar products, but this one stands out. The attention
                            to detail and customer support are unmatched."</p>
                        <h5 className="fw-bold mb-1">Michael Chen</h5>
                        <p className="text-muted">Software Engineer</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <div className="testimonial-card text-center">
                        <img src={blankProfilePic} alt="Client 3" className="testimonial-img mb-4" />
                        <p className="lead mb-4">"This solution has streamlined our processes and improved team
                            collaboration. It's been a fantastic investment for our company."</p>
                        <h5 className="fw-bold mb-1">Emily Rodriguez</h5>
                        <p className="text-muted">Project Manager</p>
                    </div>
                </div>
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    </div>

    <div className="Clients py-lg-8 py-6">
      <h1 className="clientsHeading">Clients</h1>
		 <div class="container py-lg-6">
				<div class="row">
					 <div class="col-md-12">
							<div class="d-flex justify-content-center text-center mb-6">
								 <h5 className="clientsHeadingh5">Loved by over 5 million users from companies like</h5>
							</div>
					 </div>
				</div>
				<div class="row row-cols-xl-7 gy-6">
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage1} alt="logo 1" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage2} alt="logo 2" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage3} alt="logo 3" />
					 </div>
					 {/* <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage4} alt="logo 4" />
					 </div> */}
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage5} alt="logo 5" />
					 </div>
					 <div class="border-end-0 border-end-md text-center col">
							<img src={clientsImage6} alt="logo 6" />
					 </div>
					 <div class="text-center col">
							<img src={clientsImage7} alt="logo 7" />
					 </div>
				</div>
		 </div>
    </div>

    {/* <div id="contactForm">
      <Row>
        <Col md={3}></Col>
        <Col md={6}>
          <h1 className='contactHeading'>Contact Us</h1>
            <form>
              <div data-mdb-input-init className="form-outline mb-4">
                <label className="form-label" for="form4Example1">Name</label>
                <input type="text" id="form4Example1" className="form-control" />
              </div>

              <div data-mdb-input-init className="form-outline mb-4">
                <label className="form-label" for="form4Example2">Email address</label>
                <input type="email" id="form4Example2" className="form-control" />
              </div>

              <div data-mdb-input-init className="form-outline mb-4">
                <label className="form-label" for="form4Example2">Phone Number</label>
                <input type="number" id="form4Example2" className="form-control" />
              </div>

              <div data-mdb-input-init className="form-outline mb-4">
                <label className="form-label" for="form4Example3">Message</label>
                <textarea className="form-control" id="form4Example3" rows="4"></textarea>
              </div>

              <div className="form-check d-flex justify-content-center mb-4">
                
              </div>

              <button data-mdb-ripple-init type="button" className="btn btn-primary btn-block mb-4">Send</button>
            </form>        
        </Col>
        <Col md={3}></Col>
      </Row>

    </div> */}

  </div>
);

Home.propTypes = {};

Home.defaultProps = {};

export default Home;
