import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Nav from "./components/Nav/Nav";
import Home from "./components/Home/Home";
import About from "./components/About/About";
import Contact from "./components/Contact/Contact";
import Footer from "./components/Footer/Footer";
import Services from "./components/Services/Services";
import FAQ from "./components/FAQ/FAQ";
import Blogs from "./components/Blogs/Blogs";
import Testimonials from "./components/Testimonials/Testimonials";
import Team from "./components/Team/Team";
import Clients from './components/Clients/Clients';
import Gallery from './components/Gallery/Gallery';
import Blog1 from './components/Blog1/Blog1';
import Blog2 from './components/Blog2/Blog2';
import Blog3 from './components/Blog3/Blog3';

function App() {
  return (
        <BrowserRouter>
        <Nav />
          <Routes>
              <Route path="/" element={<Home />} />
              <Route path="about" element={<About />} />
              <Route path="services" element={<Services />} />
              <Route path="gallery" element={<Gallery />} />
              <Route path="faq" element={<FAQ />} />
              <Route path="team" element={<Team />} />
              <Route path="testimonials" element={<Testimonials />} />
              <Route path="blogs" element={<Blogs />} />
              <Route path="blog1" element={<Blog1 />} />
              <Route path="blog2" element={<Blog2 />} />
              <Route path="blog3" element={<Blog3 />} />
              <Route path="clients" element={<Clients />} />
              <Route path="contact" element={<Contact />} />
          </Routes>
         <Footer /> 
        </BrowserRouter>
        
  );
}

export default App;
