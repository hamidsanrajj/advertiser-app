import './Carousel.css';
import image1 from './img/large-format-printing-1.jpeg';
import image2 from './img/Alpen-Signs-Types-of-signage-Freestanding.jpg';
import image3 from './img/store-branding.jpeg';
import image4 from './img/Vehicle-branding-1.png';
import image5 from './img/parallelogram-brochure.jpg';
import image6 from './img/8-Large-Format-Laser-Printers-for-Your-Small-Business.png';
import image7 from './img/OFFSET-1.png';
import image8 from './img/1-200530161450T7.png';
import image9 from './img/fiber-laser-part-marking-anywhere-1656704646.jpeg';

const Carousel = () => (
  <div className="Carousel">
    <div id="carouselExample" className="carousel slide">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img src={image1} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Large Format Printing</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image2} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Signage</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image3} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Instore Branding</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image4} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Vehicle Branding</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image5} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Creative Ideas</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image6} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Laser Cutting</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image7} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Offset Printing</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image8} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>UV FLat Bed Printing</span></p>
          </div>
        </div>
        <div className="carousel-item">
          <img src={image9} className="d-block w-100" alt="..." data-bs-interval="3000" />
          <div className="carousel-caption d-none d-md-block">
            <p><span>Fiber Metal Marking</span></p>
          </div>
        </div>
      </div>
      <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
      </button>
      <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
      </button>
    </div>


  </div>
);

Carousel.propTypes = {};

Carousel.defaultProps = {};

export default Carousel;
