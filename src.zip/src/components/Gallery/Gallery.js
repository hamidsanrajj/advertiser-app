import './Gallery.css';
import galleryImage1 from './img/gallery/brouchers.jpg'
import galleryImage2 from './img/gallery/mugs.webp';
import galleryImage3 from './img/gallery/shields.jpeg';
import galleryImage4 from './img/gallery/stamp.webp';
import galleryImage5 from './img/gallery/envelopes.webp';
import galleryImage6 from './img/gallery/t-shirts.jpg';

const Gallery = () => (
  <div className="Gallery">
    <h1 className='Heading-Main'>Gallery</h1>
    
    <div className='gallery'>
      {/* <h1 className='galleryHeading'>Gallery</h1> */}
      <div class="row">
        <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
          <img
            src={galleryImage1}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Boat on Calm Water"
          />

          <img
            src={galleryImage2}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Wintry Mountain Landscape"
          />
        </div>

        <div class="col-lg-4 mb-4 mb-lg-0">
          <img
            src={galleryImage3}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Mountains in the Clouds"
          />

          <img
            src={galleryImage6}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Boat on Calm Water"
          />
        </div>

        <div class="col-lg-4 mb-4 mb-lg-0">
          <img
            src={galleryImage5}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Waves at Sea"
          />

          <img
            src={galleryImage4}
            class="w-100 shadow-1-strong rounded mb-4"
            alt="Yosemite National Park"
          />
        </div>
      </div>
    </div>

  </div>
);

Gallery.propTypes = {};

Gallery.defaultProps = {};

export default Gallery;
