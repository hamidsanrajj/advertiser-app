import './FAQ.css';
import Accordion from 'react-bootstrap/Accordion';

const Faq = () => (
  <div className="FAQ">
    <h1 className='Heading-Main'>FAQ</h1>
    <div className='faq'> 
      {/* <h1 className='faqHeading'>FAQ's</h1> */}
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0">
          <Accordion.Header>What is Large Format Printing ?</Accordion.Header>
          <Accordion.Body>
            Large format printing is a specialized printing process used to produce graphics and prints larger than what standard desktop or commercial printers can handle. It typically involves using specialized equipment like flatbed printers or roll-to-roll printers to print on materials like banners, posters, and trade show displays. These prints are often used for advertising, signage, and visual communication in larger spaces. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="1">
          <Accordion.Header>What is Signage ?</Accordion.Header>
          <Accordion.Body>
            Signage is the design or use of signs and symbols to communicate a message. Signage also means signs collectively or being considered as a group. The term signage is documented to have been popularized in 1975 to 1980. Signs are any kind of visual graphics created to display information to a particular audience.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="2">
          <Accordion.Header>What is Instore Branding ?</Accordion.Header>
          <Accordion.Body>
            In-store branding is a strategic approach that uses visual elements, product placement, and even sensory experiences within a store to create a consistent and memorable brand experience for customers. It's about expressing a brand's identity, values, and products through the physical environment, aiming to make customers feel connected to the brand and its message. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="3">
          <Accordion.Header>What is Vehicle Branding ?</Accordion.Header>
          <Accordion.Body>
            The goal of vehicle branding is to turn your company vehicle into a mobile billboard that showcases your brand wherever it goes. Whether you have a single company car, van, lorry, or an entire fleet of vehicles, vehicle branding can significantly boost your marketing efforts.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="4">
          <Accordion.Header>What is Laser Cutting ?</Accordion.Header>
          <Accordion.Body>
            Laser cutting is a technology that uses a laser to vaporize materials, resulting in a cut edge. While typically used for industrial manufacturing applications, it is now used by schools, small businesses, architecture, and hobbyists. Laser cutting works by directing the output of a high-power laser most commonly through optics. The laser optics and CNC (computer numerical control) are used to direct the laser beam to the material. A commercial laser for cutting materials uses a motion control system to follow a CNC or G-code of the pattern to be cut onto the material. The focused laser beam is directed at the material, which then either melts, burns, vaporizes away, or is blown away by a jet of gas, leaving an edge with a high-quality surface finish.
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="5">
          <Accordion.Header>What is Offset Printing ?</Accordion.Header>
          <Accordion.Body>
            Offset printing, also known as offset lithography, is a printing process where ink is transferred from a plate to a rubber blanket, which then transfers the image to the printing surface. This "offset" step reduces wear and tear on the plate and allows for high-quality printing on various substrates. 
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="6">
          <Accordion.Header>What is UV Flat Bed Printing ?</Accordion.Header>
          <Accordion.Body>
            UV flatbed printing is a digital printing process that uses ultraviolet light to instantly cure and dry ink on a flatbed surface. It allows for printing on a wide variety of materials, including rigid and flexible substrates, and is known for its high-quality, durable prints and fast turnaround times. 
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>
    </div>
  </div>
);

Faq.propTypes = {};

Faq.defaultProps = {};

export default Faq;
