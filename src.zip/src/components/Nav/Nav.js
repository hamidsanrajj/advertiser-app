import { NavLink } from "react-router-dom";
import "./Nav.css";
import Logo from "./logo.jpeg";
import { Col, Row } from "react-bootstrap";

const Nav = () => (
  <header className="header">
     <nav className="nav">      
       <div className="top_header"> 
        {/* <p className="email"> <b> Email: </b> info@carhireislamabad.com </p>  */}
        <Row>
          <Col md={4}>
            Email: info@goharadvertiser.com
          </Col>
          <Col md={4}>
            Phone: 03356699972 / 03360591298
          </Col>
          <Col md={4}>
            Address: 17-A Basement, Itehad Centre Blue Area, IBD         
          </Col>
        </Row>
       </div>
       <div className="logo">
        <img className="Logo" src={Logo} alt="" />
       </div>
       <div
         className={"nav__menu"}
         id="nav-menu">
         <ul className="nav__list">
           <li className="nav__item">
             <NavLink to="/" className="nav__link item_nav"> 
               Home
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/about" className="nav__link">
               About
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/services" className="nav__link">
               Services
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/gallery" className="nav__link">
               Gallery
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/faq" className="nav__link">
               FAQ
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/team" className="nav__link">
               Team
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/testimonials" className="nav__link">
               Testimonials
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/blogs" className="nav__link">
               Blogs
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/clients" className="nav__link">
               Clients
             </NavLink>
           </li>
           <li className="nav__item">
             <NavLink to="/contact" className="nav__link">
               Contact
             </NavLink>
           </li>
         </ul>
       </div>
     </nav>
   </header>
);

Nav.propTypes = {};

Nav.defaultProps = {};

export default Nav;
