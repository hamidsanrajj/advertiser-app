import './Blog3.css';
import advertisingPoster from './img/Advertising-Poster-Templates.png';

const Blog3 = () => (
  <div className="Blog3">
    <h1>How to make a successful advertising poster</h1>
    <p>Posted on May 19, 2025</p>
    <img src={advertisingPoster} className='advertisingPoster' />
    <p>Do you need tips and tricks on how to make an advertising poster for your company? You have come to the right place. At Gohar Advertiser we have years of experience in printing personalized advertising posters and we want to share all our secrets with you.

In today’s article, you will find everything you need to create your successful posters suitable for a good impression. With our advice, you will be able to make very striking and high-quality posters. Don’t miss it!</p>
  </div>
);

Blog3.propTypes = {};

Blog3.defaultProps = {};

export default Blog3;
