import './Services.css';

const Services = () => (
  <div className="Services">
      <h1 className='Heading-Main'>Services</h1>

      <div className='services services-section' id="services">
      {/* <h1 className='headingServices'>Services</h1> */}
      {/* <Container>
        <Row className='service-1'>
          <Col md={4} className='service'>Service 1</Col>
          <Col md={4} className='service'>Service 2</Col>
          <Col md={4} className='service'>Service 3</Col>
        </Row>
        <Row className='service-2'> 
          <Col md={4} className='service'>Service 1</Col>
          <Col md={4} className='service'>Service 2</Col>
          <Col md={4} className='service'>Service 3</Col>
        </Row>
      </Container> */}

    <div className="container">
        <div className="row">
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Large Format Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Signage</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Instore Branding</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Vehicle Branding</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Creative Ideas</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Laser Cutting</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>OffSet Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>UV FlatBed Printing</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
            <div className="col-sm-6 col-lg-4">
                <div className="feature-box-1">
                    <div className="icon">
                        <i className="fa fa-print"></i>
                    </div>
                    <div className="feature-content">
                        <h5>Fiber Metal Marking</h5>
                        <p>We design and develop services for customers of all sizes, specializing in creating stylish, modern designs.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
  </div>
);

Services.propTypes = {};

Services.defaultProps = {};

export default Services;
