import './Blogs.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import imageFoodTruck from './img/food-truck.jpg';
import printingImage from './img/digital-priniting_367726020_S.jpg';
import advertisingPoster from './img/Advertising-Poster-Templates.png';

const Blogs = () => (
  <div className="Blogs">
      <h1 className='Heading-Main'>Blogs</h1>


    <div className='blogs'>
      <h1 className='blogHeading'> Blogs </h1>
      <Row>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={imageFoodTruck} className='cardImage' />
              <Card.Body>
                <Card.Title>How to Design an Impactful Flyer</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025 
                </Card.Text>
                <Link to="/blog1"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={printingImage} className='cardImage' />
              <Card.Body>
                <Card.Title>How to Stand Out in a Crowded Print Market with Value-Driven Services</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025 
                </Card.Text>
                <Link to="/blog2"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
        <Col md={4}>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={advertisingPoster} className='cardImage' />
              <Card.Body>
                <Card.Title>How to make a successful advertising poster</Card.Title>
                <Card.Text>
                  Posted on May 19, 2025
                </Card.Text>
                <Link to="/blog3"> 
                    <Button variant="primary">Read More</Button>
                </Link>
              </Card.Body>
            </Card>
        </Col>
      </Row>
    </div>


  </div>
);

Blogs.propTypes = {};

Blogs.defaultProps = {};

export default Blogs;
